<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>
<!-- Scripts
================================================== -->
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/chosen.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/magnific-popup.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/owl.carousel.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/rangeSlider.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/sticky-kit.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/slick.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/masonry.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/mmenu.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/tooltips.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/custom.js"></script>

<!-- Maps -->
<script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyDmyasSBWi-tlcG7yXyiAR3cUlBT0vylgQ&sensor=false&language=en"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/infobox.min.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/markerclusterer.js"></script>
<script type="text/javascript" src="{{ url('frontend/') }}/scripts/maps.js"></script>


@yield('js_after')
