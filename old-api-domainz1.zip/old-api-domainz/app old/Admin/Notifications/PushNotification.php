<?php

namespace App\Admin\Notifications;

use Illuminate\Database\Eloquent\Model;

class PushNotification extends Model
{
	protected $table = 'push_notifications';
}