<?php

namespace App\Admin\BankAccounts;

use Illuminate\Database\Eloquent\Model;

class BankAccount extends Model
{
    //
}
