<?php

namespace App\Admin\AccountType;

use Illuminate\Database\Eloquent\Model;

class AccountType extends Model
{
	protected $table = 'account_type';
}
